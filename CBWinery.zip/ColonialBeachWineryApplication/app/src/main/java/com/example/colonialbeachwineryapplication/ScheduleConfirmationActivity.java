package com.example.colonialbeachwineryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ScheduleConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_confirmation);
        ScheduleData sd = (ScheduleData) getIntent().getSerializableExtra("Schedule");

        TextView txtConfirmName = findViewById(R.id.txtConfirmName);
        TextView txtConfirmPhone = findViewById(R.id.txtConfirmPhone);
        TextView txtConfirmEmail = findViewById(R.id.txtConfirmEmail);
        TextView txtConfirmDate = findViewById(R.id.txtConfirmDate);
        TextView txtConfirmTime = findViewById(R.id.txtConfirmTime);

        txtConfirmName.setText(txtConfirmName.getText().toString() + " "+ sd.getName());
        txtConfirmPhone.setText(txtConfirmPhone.getText().toString() + " "+ sd.getPhone());
        txtConfirmEmail.setText(txtConfirmEmail.getText().toString() + " "+ sd.getEmail());
        txtConfirmDate.setText(txtConfirmDate.getText().toString() + " "+ sd.getDate());
        txtConfirmTime.setText(txtConfirmTime.getText().toString() + " "+ sd.getTime());

    }
}
